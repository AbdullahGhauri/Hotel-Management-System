package com.example.ghaurihotel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.widget.Toolbar;
import androidx.room.Room;

import com.example.ghaurihotel.DataBase.MyDataBase;
import com.example.ghaurihotel.DataBase.Tables.Address;
import com.example.ghaurihotel.DataBase.Tables.Booking;
import com.example.ghaurihotel.DataBase.Tables.BookingDate;
import com.example.ghaurihotel.DataBase.Tables.Branch;
import com.example.ghaurihotel.DataBase.Tables.Hotel;
import com.example.ghaurihotel.DataBase.Tables.RoomDetail;
import com.example.ghaurihotel.DataBase.Tables.RoomType;
import com.facebook.login.LoginManager;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;


import static android.widget.Toast.makeText;

public class HomePage extends AppCompatActivity {

    DrawerLayout drawer;
    NavigationView navigationView;
    Toolbar toolbar;
    ActionBarDrawerToggle toggle;
    Spinner selectBranch, selectRoomType;
    Button searchRoom,checkInDate,checkOutDate;
    EditText numberOfRooms;
    DatePicker bookingDate;
    public int checkInDay;
    public int checkInMonth;
    public int checkInYear;
    public int checkOutDay;
    public int checkOutMonth;
    public int checkOutYear;
    public HashMap<String,Integer> hashMap;
    private MyDataBase myDataBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        selectBranch = findViewById(R.id.selectBranch);
        String[] hotelBranchs = new String[]{"TandoAllahyar"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, hotelBranchs);
        selectBranch.setAdapter(adapter);
        selectRoomType = findViewById(R.id.selectRoomType);
        String[] hotelRoomtype = new String[]{"Deluxe Room","Twin Room"};
        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, hotelRoomtype);
        selectRoomType.setAdapter(adapter1);

        searchRoom = (Button) findViewById(R.id.searchRoom);
        numberOfRooms = (EditText) findViewById(R.id.numberOfRooms);
        checkInDate = (Button) findViewById(R.id.checkInDate);
        checkOutDate = (Button) findViewById(R.id.checkOutDate);
        bookingDate = (DatePicker) findViewById(R.id.bookingDate);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        navigationView = (NavigationView) findViewById(R.id.navigation);
        drawer = (DrawerLayout) findViewById(R.id.drawer);
        hashMap = new HashMap<>();
        hashMap.put("Deluxe Room",2);
        hashMap.put("Twin Room",2);

        setSupportActionBar(toolbar);
        toggle = new ActionBarDrawerToggle(this,drawer,toolbar,R.string.open,R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();



        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                 drawer.closeDrawer(GravityCompat.START);
                 switch (item.getItemId()){
                     case R.id.loginBooking:
                         makeText(getApplicationContext(),"Login",Toast.LENGTH_LONG).show();
                         break;
                     case R.id.mybooking:
                         Intent intent = new Intent(getApplicationContext(),MyBooking.class);
                         startActivity(intent);
                         break;
                     case R.id.bookingCancellation:
                         Intent intent1 = new Intent(getApplicationContext(),CancelBooking.class);
                         startActivity(intent1);
                         break;
                     case R.id.appPrivacy:
                         Intent intent2 = new Intent(getApplicationContext(),AppPrivacy.class);
                         startActivity(intent2);
                         break;
                     case R.id.setting:
                         makeText(getApplicationContext(),"Setting",Toast.LENGTH_LONG).show();
                         break;
                     case R.id.aboutUs:
                         makeText(getApplicationContext(),"Setting",Toast.LENGTH_LONG).show();
                         break;
                     case R.id.logOut:
                         alertDialogeMethod();
                         break;

                 }


                return true;
            }
        });

        checkInDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Calendar c = Calendar.getInstance();
                Date currentDate = new Date();
                currentDate.setDate(c.get(Calendar.DAY_OF_MONTH));
                currentDate.setMonth(c.get(Calendar.MONTH));
                currentDate.setYear( c.get(Calendar.YEAR));

                checkInDay = bookingDate.getDayOfMonth();
                checkInMonth = bookingDate.getMonth()+1;
                checkInYear = bookingDate.getYear();

                Date date1 = new Date();
                date1.setDate(checkInDay);
                date1.setMonth(checkInMonth);
                date1.setYear(checkInYear);

                if(currentDate.compareTo(date1) < 0) {
                    makeText(getApplicationContext(), "Check in date selected", Toast.LENGTH_LONG).show();
                }
                else{
                    makeText(getApplicationContext(),"Recheck check in date",Toast.LENGTH_SHORT).show();
                }
            }
        });

        checkOutDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkOutDay = bookingDate.getDayOfMonth();
                checkOutMonth = bookingDate.getMonth()+1;
                checkOutYear = bookingDate.getYear();


                //  0 comes when two date are same,
                //  1 comes when date1 is higher then date2
                // -1 comes when date1 is lower then date2
                Date date1 = new Date();
                date1.setDate(checkInDay);
                date1.setMonth(checkInMonth);
                date1.setYear(checkInYear);

                Date date2 = new Date();
                date2.setDate(checkOutDay);
                date2.setMonth(checkOutMonth);
                date2.setYear(checkOutYear);

                if(date1.compareTo(date2) < 0) {
                    makeText(getApplicationContext(), "Check out date selected", Toast.LENGTH_SHORT).show();
                }
                else{
                    makeText(getApplicationContext(),"Recheck check out date",Toast.LENGTH_SHORT).show();
                }

            }
        });



        searchRoom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(numberOfRooms.getText().toString().matches("")){
                    makeText(getApplicationContext(),"Enter number of Room",Toast.LENGTH_LONG).show();
                }
                else if(Integer.parseInt(numberOfRooms.getText().toString())  < 1){
                    makeText(getApplicationContext(),"Add atleast one room",Toast.LENGTH_LONG).show();
                }
                else if(checkInDay == 0 || checkInMonth == 0 || checkInYear == 0){
                    makeText(getApplicationContext(),"Enter check in Date",Toast.LENGTH_LONG).show();
                }
                else if(checkOutDay == 0 || checkOutMonth == 0 || checkOutYear == 0){
                    makeText(getApplicationContext(),"Enter check out date",Toast.LENGTH_LONG).show();
                }
                else {
                    searchMehtod();

                }
            }
        });

    }



    private void searchMehtod() {

        Calendar c = Calendar.getInstance();
        Date currentDate = new Date();
        currentDate.setDate(c.get(Calendar.DAY_OF_MONTH));
        currentDate.setMonth(c.get(Calendar.MONTH));
        currentDate.setYear( c.get(Calendar.YEAR));

        Date date1 = new Date();
        date1.setDate(checkInDay);
        date1.setMonth(checkInMonth);
        date1.setYear(checkInYear);

        Date date2 = new Date();
        date2.setDate(checkOutDay);
        date2.setMonth(checkOutMonth);
        date2.setYear(checkOutYear);

        int temp = hashMap.get(selectRoomType.getSelectedItem().toString());


        int countOfRoom =  Integer.parseInt(numberOfRooms.getText().toString());
        if(countOfRoom <= temp){
            int temp1 = temp-countOfRoom;
            searchDate(date1,date2,temp1);
        }
        else {
            makeText(getApplicationContext(),""+countOfRoom+" room are not available",Toast.LENGTH_LONG).show();
        }



    }

    private void searchDate(Date checkInDate,Date checkOutDate,int temp3) {

        ArrayList<Integer> checkIN = new ArrayList<Integer>();
        ArrayList<Integer> checkOUT = new ArrayList<Integer>();
        ArrayList<Date> finalDateCheckIn = new ArrayList<>();
        ArrayList<Date> finalDateCheckOut = new ArrayList<>();
        ArrayList<Boolean> isRoomBooked = new ArrayList<>();
        ArrayList<Integer> roomNumber = new ArrayList<>();

        myDataBase = Room.databaseBuilder(HomePage.this, MyDataBase.class,"ghaurihotelDB").allowMainThreadQueries().build();
        List<RoomType> data = myDataBase.dao().RommTypeDao(selectRoomType.getSelectedItem().toString());
        for(int i=0;i<data.size();i++) {
            try {
                int roomTypeID = data.get(i).getRoomTypeID();
                Log.d("DATA", String.valueOf("room type id "+roomTypeID));


                myDataBase = Room.databaseBuilder(HomePage.this, MyDataBase.class,"ghaurihotelDB").allowMainThreadQueries().build();
                List<RoomDetail> data1 = myDataBase.dao().RommDetailDao(1,roomTypeID);
                for(int j=0;j<data1.size();j++) {
                    try {
                        int temp2 = data1.get(j).getRoomID();

                        Log.d("DATA", String.valueOf("roomdetail "+temp2));
                        myDataBase = Room.databaseBuilder(HomePage.this, MyDataBase.class,"ghaurihotelDB").allowMainThreadQueries().build();
                        List<Booking> data2 = myDataBase.dao().bookingDao(temp2);
                        for(int k=0;k<data2.size();k++) {
                            try {

                                checkIN.add(data2.get(k).getCheckIn());
                                checkOUT.add(data2.get(k).getCheckOut());
                                isRoomBooked.add(data2.get(k).isBooked());
                                roomNumber.add(data2.get(k).getNumberOfRoom());



                                Log.d("DATA", String.valueOf("check in date "+data2.get(k).getCheckIn()));
                                Log.d("DATA", String.valueOf("check out date "+data2.get(k).getCheckOut()));


                            }
                            catch (Exception e){
                                Log.d("ex",""+e);
                            }
                        }


                    }
                    catch (Exception e){
                        Log.d("ex",""+e);
                    }
                }
            }
            catch (Exception e){
                Log.d("ex",""+e);
            }
        }


        for (int l=0;l<checkIN.size();l++){

            myDataBase = Room.databaseBuilder(HomePage.this, MyDataBase.class,"ghaurihotelDB").allowMainThreadQueries().build();
            List<BookingDate> data3 = myDataBase.dao().search(checkIN.get(l));
            for(int k=0;k<data3.size();k++) {
                try {
                    Date date1 = new Date();
                    date1.setDate(data3.get(k).getDay());
                    date1.setMonth(data3.get(k).getMonth());
                    date1.setYear(data3.get(k).getYear());
                    finalDateCheckIn.add(date1);

                    Log.d("DATA", String.valueOf("check in date "+data3.get(k).getDay()+"/"+data3.get(k).getMonth()+"/"+data3.get(k).getYear()));

                }
                catch (Exception e){
                    Log.d("ex",""+e);
                }
            }

            myDataBase = Room.databaseBuilder(HomePage.this, MyDataBase.class,"ghaurihotelDB").allowMainThreadQueries().build();
            List<BookingDate> data4 = myDataBase.dao().search(checkOUT.get(l));
            for(int k=0;k<data4.size();k++) {
                try {
                    Date date2 = new Date();
                    date2.setDate(data4.get(k).getDay());
                    date2.setMonth(data4.get(k).getMonth());
                    date2.setYear(data4.get(k).getYear());
                    finalDateCheckOut.add(date2);

                    Log.d("DATA", String.valueOf("check in date "+data4.get(k).getDay()+"/"+data4.get(k).getMonth()+"/"+data4.get(k).getYear()));
                }
                catch (Exception e){
                    Log.d("ex",""+e);
                }
            }
        }

        int bool = 0;
        for (int a=0;a<finalDateCheckIn.size();a++){
            Log.d("DATA", String.valueOf("check final in date "+finalDateCheckIn.get(a).getDate()+"/"+finalDateCheckIn.get(a).getMonth()+"/"+finalDateCheckIn.get(a).getYear()));
            Log.d("DATA", String.valueOf("check final out date "+finalDateCheckOut.get(a).getDate()+"/"+finalDateCheckOut.get(a).getMonth()+"/"+finalDateCheckOut.get(a).getYear()));
            Log.d("DATA", String.valueOf("check final out date "+checkInDate.getDate()+"/"+checkInDate.getMonth()+"/"+checkInDate.getYear()));


            //  0 comes when two date are same,
            //  1 comes when date1 is higher then date2
            // -1 comes when date1 is lower then date2

            int temp = Integer.parseInt(numberOfRooms.getText().toString())+roomNumber.get(a);
            Log.d("DATA", String.valueOf("room numbers "+roomNumber.get(a)));
            Log.d("DATA", String.valueOf("add "+temp));

            if(finalDateCheckIn.get(a).compareTo(checkInDate) <= 0 && finalDateCheckOut.get(a).compareTo(checkInDate) >= 0 && isRoomBooked.get(a) && temp >2 ){
                bool=1;
            }
           /* else {
                bool=0;
            }*/
        }
        if(bool==0){

            hashMap.replace(selectRoomType.getSelectedItem().toString(),temp3);
            Intent intent = new Intent(getApplicationContext(),RoomBooking.class);
            intent.putExtra("roomtype_intent", selectRoomType.getSelectedItem().toString());
            intent.putExtra("checkInDay", checkInDay);
            intent.putExtra("checkInMonth", checkInMonth);
            intent.putExtra("checkInDYear", checkInYear);
            intent.putExtra("checkOutDay", checkOutDay);
            intent.putExtra("checkOutMonth", checkOutMonth);
            intent.putExtra("checkOutYear", checkOutYear);
            intent.putExtra("numberOfRoom", Integer.parseInt(numberOfRooms.getText().toString()));
            startActivity(intent);
        }
        else  {
            makeText(getApplicationContext(),"Not Available",Toast.LENGTH_LONG).show();
        }/*
        else if(bool==1) {
            makeText(getApplicationContext(),"Failed",Toast.LENGTH_LONG).show();
        }*/
    }

    private void alertDialogeMethod() {

        AlertDialog.Builder builder = new AlertDialog.Builder(HomePage.this);
        builder.setMessage("do you want to logout");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                FirebaseAuth.getInstance().signOut();
                LoginManager.getInstance().logOut();
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
                finish();
                HomePage.this.finish();

            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    @Override
    public void onBackPressed() {
        if(drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }

        moveTaskToBack(true);
        super.onBackPressed();
    }
}
