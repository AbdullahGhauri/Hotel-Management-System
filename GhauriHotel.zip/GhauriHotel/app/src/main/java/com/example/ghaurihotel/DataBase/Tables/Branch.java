package com.example.ghaurihotel.DataBase.Tables;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Branch {
    @PrimaryKey(autoGenerate = true)
    private int branchID;
    private int hotelID;
    private int addressID;


    public Branch(int hotelID, int addressID) {
        this.hotelID = hotelID;
        this.addressID = addressID;
    }

    public int getBranchID() {
        return branchID;
    }

    public void setBranchID(int branchID) {
        this.branchID = branchID;
    }

    public int getHotelID() {
        return hotelID;
    }

    public void setHotelID(int hotelID) {
        this.hotelID = hotelID;
    }

    public int getAddressID() {
        return addressID;
    }

    public void setAddressID(int addressID) {
        this.addressID = addressID;
    }
}
