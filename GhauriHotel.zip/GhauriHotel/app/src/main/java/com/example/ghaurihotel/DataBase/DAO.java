package com.example.ghaurihotel.DataBase;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;



import com.example.ghaurihotel.DataBase.Tables.Address;
import com.example.ghaurihotel.DataBase.Tables.Booking;
import com.example.ghaurihotel.DataBase.Tables.BookingDate;
import com.example.ghaurihotel.DataBase.Tables.Branch;
import com.example.ghaurihotel.DataBase.Tables.Customer;
import com.example.ghaurihotel.DataBase.Tables.Hotel;
import com.example.ghaurihotel.DataBase.Tables.RoomDetail;
import com.example.ghaurihotel.DataBase.Tables.RoomType;

import java.util.List;

@Dao
public interface DAO {


    @Insert
    public long insertHotel(Hotel hotel);

    @Insert
    public long addressDetails(Address address);

    @Insert
    public long insertHotelBranch(Branch branch);

    @Insert
    public long roomTypeDetails(RoomType roomType);

    @Insert
    public long roomDetails(RoomDetail roomDetail);

    @Insert
    public long bookingDateDao(BookingDate bookingDate);

    @Insert
    public void booking(Booking booking);

    @Insert
    public long customerDao(Customer customer);


    @Query("Select * from RoomType where roomTypeName=:type")
    List<RoomType> RommTypeDao(String type);

    @Query("Select * from RoomType where roomTypeID=:temp")
    List<RoomType> RommTypeObject(int temp);

    @Query("Select * from RoomDetail where branchID=:temp1 AND roomTypeID=:temp2")
    List<RoomDetail> RommDetailDao(int temp1,int temp2);



    @Query("Select * from RoomDetail where roomID=:temp1")
    List<RoomDetail> myBookingRoomDetails(int temp1);



    @Query("Select * from Booking where roomDetailID=:temp1")
    List<Booking> bookingDao(int temp1);

    @Query("Select * from BookingDate where bookingDate=:temp")
    List<BookingDate> search(int temp);

    @Query("Select * from Booking")
    List<Booking> myBooking();

    @Query("Update Booking set booked=:temp where bookingID = :temp1")
    void update(boolean temp,int temp1);


}

