package com.example.ghaurihotel.DataBase.Tables;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Customer {

    @PrimaryKey(autoGenerate = true)
    private int customerID;
    private String customerName;
    private String emailAddress;
    private String CNIC;
    private String contact;
    private int addressID;

    public Customer(String customerName, String emailAddress, String CNIC, String contact, int addressID) {
        this.customerName = customerName;
        this.emailAddress = emailAddress;
        this.CNIC = CNIC;
        this.contact = contact;
        this.addressID = addressID;
    }


    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getCNIC() {
        return CNIC;
    }

    public void setCNIC(String CNIC) {
        this.CNIC = CNIC;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public int getAddressID() {
        return addressID;
    }

    public void setAddressID(int addressID) {
        this.addressID = addressID;
    }
}
