package com.example.ghaurihotel.DataBase.Tables;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Hotel {
    @PrimaryKey(autoGenerate = true)
    private int hotelID;
    private String hotelName;

    public Hotel(String hotelName) {
        this.hotelName = hotelName;
    }

    public int getHotelID() {
        return hotelID;
    }

    public void setHotelID(int hotelID) {
        this.hotelID = hotelID;
    }

    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }
}
