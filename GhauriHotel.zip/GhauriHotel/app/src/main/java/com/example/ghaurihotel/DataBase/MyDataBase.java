package com.example.ghaurihotel.DataBase;
import androidx.room.Dao;
import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.ghaurihotel.DataBase.Tables.Address;
import com.example.ghaurihotel.DataBase.Tables.Booking;
import com.example.ghaurihotel.DataBase.Tables.BookingDate;
import com.example.ghaurihotel.DataBase.Tables.Branch;
import com.example.ghaurihotel.DataBase.Tables.Customer;
import com.example.ghaurihotel.DataBase.Tables.Hotel;
import com.example.ghaurihotel.DataBase.Tables.RoomDetail;
import com.example.ghaurihotel.DataBase.Tables.RoomType;

@Database(entities = {Address.class, Booking.class, Branch.class, Customer.class, Hotel.class, RoomDetail.class, RoomType.class, BookingDate.class} ,version =1,exportSchema = false)
public abstract class MyDataBase extends RoomDatabase {
    public abstract DAO dao();
}
