package com.example.ghaurihotel.DataBase.Tables;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.HashMap;

@Entity
public class RoomType {

    @PrimaryKey(autoGenerate = true)
    private int roomTypeID;
    private String roomTypeName;
    private int roomCount;


    public RoomType(String roomTypeName, int roomCount) {
        this.roomTypeName = roomTypeName;
        this.roomCount = roomCount;
    }

    public int getRoomTypeID() {
        return roomTypeID;
    }

    public void setRoomTypeID(int roomTypeID) {
        this.roomTypeID = roomTypeID;
    }

    public String getRoomTypeName() {
        return roomTypeName;
    }

    public void setRoomTypeName(String roomTypeName) {
        this.roomTypeName = roomTypeName;
    }

    public int getRoomCount() {
        return roomCount;
    }

    public void setRoomCount(int roomCount) {
        this.roomCount = roomCount;
    }
}
