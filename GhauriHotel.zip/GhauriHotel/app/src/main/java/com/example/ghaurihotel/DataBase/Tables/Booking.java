package com.example.ghaurihotel.DataBase.Tables;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity
public class Booking {

    @PrimaryKey(autoGenerate = true)
    private int bookingID;
    private int roomDetailID;
    private int customerID;
    private int checkIn;
    private int checkOut;
    private int numberOfRoom;
    private boolean booked;


    public Booking(int roomDetailID, int customerID, int checkIn, int checkOut, boolean booked,int numberOfRoom) {
        this.roomDetailID = roomDetailID;
        this.customerID = customerID;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.booked = booked;
        this.numberOfRoom= numberOfRoom;
    }

    public int getBookingID() {
        return bookingID;
    }

    public void setBookingID(int bookingID) {
        this.bookingID = bookingID;
    }

    public int getRoomDetailID() {
        return roomDetailID;
    }

    public void setRoomDetailID(int roomDetailID) {
        this.roomDetailID = roomDetailID;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public int getCheckIn() {
        return checkIn;
    }

    public void setCheckIn(int checkIn) {
        this.checkIn = checkIn;
    }

    public int getCheckOut() {
        return checkOut;
    }

    public void setCheckOut(int checkOut) {
        this.checkOut = checkOut;
    }

    public boolean isBooked() {
        return booked;
    }

    public void setBooked(boolean booked) {
        this.booked = booked;
    }

    public int getNumberOfRoom() {
        return numberOfRoom;
    }

    public void setNumberOfRoom(int numberOfRoom) {
        this.numberOfRoom = numberOfRoom;
    }
}
