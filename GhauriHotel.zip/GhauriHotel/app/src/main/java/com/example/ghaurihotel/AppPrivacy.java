package com.example.ghaurihotel;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.room.Room;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.ghaurihotel.DataBase.MyDataBase;
import com.example.ghaurihotel.DataBase.Tables.Address;
import com.example.ghaurihotel.DataBase.Tables.Branch;
import com.example.ghaurihotel.DataBase.Tables.Hotel;
import com.example.ghaurihotel.DataBase.Tables.RoomDetail;
import com.example.ghaurihotel.DataBase.Tables.RoomType;

public class AppPrivacy extends AppCompatActivity {

    Button add;
    MyDataBase myDataBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_privacy);

        add = (Button) findViewById(R.id.insert);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Hotel hotel = new Hotel("Ghauri Hotel");
                myDataBase = Room.databaseBuilder(AppPrivacy.this, MyDataBase.class,"ghaurihotelDB").allowMainThreadQueries().build();
                int hotelID = (int) myDataBase.dao().insertHotel(hotel);

                Address hotelAddress = new Address("Pakistan","Sindh","TandoAllahyar","Abbass town","plot 59");
                int address1 = (int) myDataBase.dao().addressDetails(hotelAddress);

                Branch branch1 = new Branch(hotelID,address1);
                int branch1Id = (int) myDataBase.dao().insertHotelBranch(branch1);

                RoomType roomType1 = new RoomType("Deluxe Room",2);
                int roomTypeID1 = (int) myDataBase.dao().roomTypeDetails(roomType1);

                RoomType roomType2 = new RoomType("Twin Room",2);
                int roomTypeID2 = (int) myDataBase.dao().roomTypeDetails(roomType2);

                RoomDetail roomDetail1 = new RoomDetail(branch1Id,roomTypeID1);
                int deluxe = (int )myDataBase.dao().roomDetails(roomDetail1);

                RoomDetail roomDetail2 = new RoomDetail(branch1Id,roomTypeID2);
                myDataBase.dao().roomDetails(roomDetail2);

                Toast.makeText(getApplicationContext(), "Added", Toast.LENGTH_SHORT).show();
            }
        });


        Toolbar myChildToolbar = (Toolbar) findViewById(R.id.roomBookingToolbar);
        setSupportActionBar(myChildToolbar);
        ActionBar ab = getSupportActionBar();
        ab.setDisplayHomeAsUpEnabled(true);
    }
}
