package com.example.ghaurihotel.DataBase.Tables;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class RoomDetail {

    @PrimaryKey(autoGenerate = true)
    private int roomID;
    private int branchID;
    private int roomTypeID;


    public RoomDetail(int branchID, int roomTypeID) {
        this.branchID = branchID;
        this.roomTypeID = roomTypeID;
    }


    public int getRoomID() {
        return roomID;
    }

    public void setRoomID(int roomID) {
        this.roomID = roomID;
    }

    public int getBranchID() {
        return branchID;
    }

    public void setBranchID(int branchID) {
        this.branchID = branchID;
    }

    public int getRoomTypeID() {
        return roomTypeID;
    }

    public void setRoomTypeID(int roomTypeID) {
        this.roomTypeID = roomTypeID;
    }
}
