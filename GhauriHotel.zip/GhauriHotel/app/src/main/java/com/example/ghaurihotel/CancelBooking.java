package com.example.ghaurihotel;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ghaurihotel.DataBase.MyDataBase;
import com.example.ghaurihotel.DataBase.Tables.Booking;
import com.example.ghaurihotel.DataBase.Tables.BookingDate;
import com.example.ghaurihotel.DataBase.Tables.RoomDetail;
import com.example.ghaurihotel.DataBase.Tables.RoomType;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CancelBooking extends AppCompatActivity {

    MyDataBase myDataBase;
    public String typeName;
    public String checkInDate;
    public String checkOutDate;
    TextView myBookingDetails;
    EditText bookingID;
    Button cancelBooking;
    public int done = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel_booking);



        myBookingDetails =(TextView) findViewById(R.id.myBookingDetails);
        bookingID = (EditText) findViewById(R.id.bookingID);
        cancelBooking = (Button) findViewById(R.id.cancelBooking);

        // disable booking which have been passed
        bookingDisabled();

        showBookings();

        cancelBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bookingID.getText().toString().matches("")){
                    Toast.makeText(getApplicationContext(),"Enter Room Booking ID",Toast.LENGTH_SHORT).show();
                }

                else {
                    myDataBase = Room.databaseBuilder(CancelBooking.this, MyDataBase.class, "ghaurihotelDB").allowMainThreadQueries().build();
                    List<Booking> data3 = myDataBase.dao().myBooking();
                    for (int k = 0; k < data3.size(); k++) {
                        try {
                            if(data3.get(k).getBookingID() == Integer.parseInt(bookingID.getText().toString()) && data3.get(k).isBooked()){
                                done = 1;
                                break;
                            }

                        } catch (Exception e) {
                            Log.d("ex", "" + e);
                        }
                    }

                    if(done == 1){
                        myDataBase.dao().update(false, Integer.parseInt(bookingID.getText().toString()));
                        Toast.makeText(getApplicationContext(), "Cancelled", Toast.LENGTH_SHORT).show();
                        bookingID.setText("");
                        Intent intent1 = new Intent(getApplicationContext(), CancelBooking.class);
                        startActivity(intent1);
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Enter correct Room Booking ID",Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });





        Toolbar myChildToolbar = (Toolbar) findViewById(R.id.roomBookingToolbar);
        setSupportActionBar(myChildToolbar);
        ActionBar ab = getSupportActionBar();
        ab.setDisplayHomeAsUpEnabled(true);
    }

    private void showBookings() {
        Date date = new Date();
        Calendar c = Calendar.getInstance();
        Date currentDate = new Date();
        currentDate.setDate(c.get(Calendar.DAY_OF_MONTH));
        currentDate.setMonth(c.get(Calendar.MONTH)+1);
        currentDate.setYear( c.get(Calendar.YEAR));
        //   Log.d("DAT", String.valueOf("OK"+c.get(Calendar.DAY_OF_MONTH)+"/"+c.get(Calendar.MONTH)+"/"+c.get(Calendar.YEAR)));


        myDataBase = Room.databaseBuilder(CancelBooking.this, MyDataBase.class,"ghaurihotelDB").allowMainThreadQueries().build();
        List<Booking> bookingObject = myDataBase.dao().myBooking();
        for(int k=0;k<bookingObject.size();k++) {
            try {
                if(bookingObject.get(k).isBooked()){
                    int temp = bookingObject.get(k).getRoomDetailID();
                    int checkIN = bookingObject.get(k).getCheckIn();
                    int checkOut = bookingObject.get(k).getCheckOut();


                    List<BookingDate> dateInOfMyBooking = myDataBase.dao().search(checkIN);
                    for(int l=0;l<dateInOfMyBooking.size();l++) {
                        try {
                            checkInDate = dateInOfMyBooking.get(l).getDay()+"/"+dateInOfMyBooking.get(l).getMonth()+"/"+dateInOfMyBooking.get(l).getYear();
                        }
                        catch (Exception e){
                            Log.d("ex",""+e);
                        }
                    }
                    List<BookingDate> dateOutOfMyBooking = myDataBase.dao().search(checkOut);
                    for(int l=0;l<dateOutOfMyBooking.size();l++) {
                        try {
                            checkOutDate = dateOutOfMyBooking.get(l).getDay()+"/"+dateOutOfMyBooking.get(l).getMonth()+"/"+dateOutOfMyBooking.get(l).getYear();
                        }
                        catch (Exception e){
                            Log.d("ex",""+e);
                        }
                    }

                    List<RoomDetail> roomDetailsObject = myDataBase.dao().myBookingRoomDetails(temp);
                    for(int j=0;j<roomDetailsObject.size();j++) {
                        try {
                            int temp1 = roomDetailsObject.get(j).getRoomTypeID();
                            List<RoomType> rommTypeObject = myDataBase.dao().RommTypeObject(temp1);
                            for(int l=0;l<rommTypeObject.size();l++) {
                                try {
                                    typeName = rommTypeObject.get(l).getRoomTypeName();
                                }
                                catch (Exception e){
                                    Log.d("ex",""+e);
                                }
                            }
                        }
                        catch (Exception e){
                            Log.d("ex",""+e);
                        }
                    }

                    Log.d("DATA", String.valueOf("OK1"+c.get(Calendar.DAY_OF_MONTH)+"/"+c.get(Calendar.MONTH)+"/"+c.get(Calendar.YEAR)));
                    String temp2 = "\n"+bookingObject.get(k).getBookingID()+"\t"+typeName+"\t"+bookingObject.get(k).getNumberOfRoom()+"\t"+checkInDate+"\t"+checkOutDate;
                    myBookingDetails.append(temp2);

                }


            }
            catch (Exception e){
                Log.d("ex",""+e);
            }


        }
    }
    private void bookingDisabled() {

        Date date = new Date();
        Calendar c = Calendar.getInstance();
        Date currentDate = new Date();
        currentDate.setDate(c.get(Calendar.DAY_OF_MONTH));
        currentDate.setMonth(c.get(Calendar.MONTH)+1);
        currentDate.setYear( c.get(Calendar.YEAR));
        Log.d("DATA", String.valueOf("OK2"+c.get(Calendar.DAY_OF_MONTH)+"/"+(c.get(Calendar.MONTH)+1)+"/"+c.get(Calendar.YEAR)));


        myDataBase = Room.databaseBuilder(CancelBooking.this, MyDataBase.class,"ghaurihotelDB").allowMainThreadQueries().build();
        List<Booking> bookingObject = myDataBase.dao().myBooking();
        for(int k=0;k<bookingObject.size();k++) {
            try {
                int checkIN = bookingObject.get(k).getCheckIn();


                List<BookingDate> dateInOfMyBooking = myDataBase.dao().search(checkIN);
                for(int l=0;l<dateInOfMyBooking.size();l++) {
                    try {
                        date.setDate(dateInOfMyBooking.get(l).getDay());
                        date.setMonth(dateInOfMyBooking.get(l).getMonth());
                        date.setYear(dateInOfMyBooking.get(l).getYear());


                        Log.d("DATA","OK"+dateInOfMyBooking.get(l).getDay()+"/"+dateInOfMyBooking.get(l).getMonth()+"/"+dateInOfMyBooking.get(l).getYear());




                    }
                    catch (Exception e){
                        Log.d("ex",""+e);
                    }
                    //  0 comes when two date are same,
                    //  1 comes when date1 is higher then date2
                    // -1 comes when date1 is lower then date2

                    if(date.compareTo(currentDate) < 0 ){
                        myDataBase.dao().update(false,bookingObject.get(k).getBookingID());
                    }
                }



            }
            catch (Exception e){
                Log.d("ex",""+e);
            }


        }

    }
}
