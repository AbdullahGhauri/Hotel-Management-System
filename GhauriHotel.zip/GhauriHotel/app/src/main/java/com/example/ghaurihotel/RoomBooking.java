package com.example.ghaurihotel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.room.Room;

import com.example.ghaurihotel.DataBase.MyDataBase;
import com.example.ghaurihotel.DataBase.Tables.Address;
import com.example.ghaurihotel.DataBase.Tables.Booking;
import com.example.ghaurihotel.DataBase.Tables.BookingDate;
import com.example.ghaurihotel.DataBase.Tables.Customer;
import com.example.ghaurihotel.DataBase.Tables.RoomDetail;
import com.example.ghaurihotel.DataBase.Tables.RoomType;

import java.util.List;

public class RoomBooking extends AppCompatActivity {

    TextView b1;
    EditText nameCustomer,cnicCustomer,contactCustomer,addressValueCustomer,townValueCustomer,emailCustomer;
    Button booked;
    Spinner countryCustomer,provinceCustomer,cityCustomer;

    public String selectedRoomType;
    public int checkInDay;
    public int checkInMonth ;
    public int checkInDYear;
    public int checkOutDay;
    public int checkOutMonth;
    public int checkOutYear;
    public int roomdetailID;
    public int numberOfRooms;
    private MyDataBase myDataBase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_booking);


        b1 = (TextView) findViewById(R.id.branchOfHotel);
        nameCustomer = (EditText) findViewById(R.id.nameCustomer);
        cnicCustomer = (EditText) findViewById(R.id.cnicCustomer);
        contactCustomer = (EditText) findViewById(R.id.contactCustomer);
        countryCustomer = (Spinner) findViewById(R.id.countryCustomer);
        provinceCustomer = (Spinner) findViewById(R.id.provinceCustomer);
        cityCustomer = (Spinner) findViewById(R.id.cityCustomer);
        addressValueCustomer = (EditText) findViewById(R.id.addressValueCustomer);
        townValueCustomer = (EditText) findViewById(R.id.townValueCustomer);
        emailCustomer = (EditText) findViewById(R.id.emailCustomer);
        booked = (Button) findViewById(R.id.booked);



        String[] country = new String[]{"Pakistan"};
        ArrayAdapter<String> countryAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, country);
        provinceCustomer.setAdapter(countryAdapter);

        String[] province = new String[]{"Sindh","Punjab","Balochistan","KPK"};
        ArrayAdapter<String> provinceAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, province);
        countryCustomer.setAdapter(provinceAdapter);

        String[] city = new String[]{"TandoAllahyar","Karachi","Larkana","Sukkar","Khanpur","Bahawalpur","Multan","Lahore","Islamabad","Peshawar","Quetta"};
        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, city);
        cityCustomer.setAdapter(cityAdapter);

        Intent innent = getIntent();
        selectedRoomType = innent.getStringExtra("roomtype_intent");
        checkInDay =innent.getExtras().getInt("checkInDay");;
        checkInMonth = innent.getExtras().getInt("checkInMonth");
        checkInDYear=innent.getExtras().getInt("checkInDYear") ;
        checkOutDay =innent.getExtras().getInt("checkOutDay") ;
        checkOutMonth = innent.getExtras().getInt("checkOutMonth");
        checkOutYear=innent.getExtras().getInt("checkOutYear") ;
        numberOfRooms=innent.getExtras().getInt("numberOfRoom") ;
        String temp = selectedRoomType+" check In "+checkInDay+"/"+checkInMonth+"/"+checkInDYear+" checkout"+checkOutDay+"/"+checkOutMonth+"/"+checkOutYear;
        b1.setText(temp);


        booked.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nameCustomer.getText().toString().matches("")){
                    Toast.makeText(getApplicationContext(),"Enter full name",Toast.LENGTH_LONG).show();
                }
                else if(cnicCustomer.getText().toString().matches("")){
                    Toast.makeText(getApplicationContext(),"Enter CNIC",Toast.LENGTH_LONG).show();
                }
                else if(contactCustomer.getText().toString().matches("")){
                    Toast.makeText(getApplicationContext(),"Enter contact number",Toast.LENGTH_LONG).show();
                }
                else if(emailCustomer.getText().toString().matches("")){
                    Toast.makeText(getApplicationContext(),"Enter your email",Toast.LENGTH_LONG).show();
                }
                else if(townValueCustomer.getText().toString().matches("")){
                    Toast.makeText(getApplicationContext(),"Enter town name",Toast.LENGTH_LONG).show();
                }

                else if(addressValueCustomer.getText().toString().matches("")){
                    Toast.makeText(getApplicationContext(),"Enter other address detail",Toast.LENGTH_LONG).show();
                }
                else{
                    insertInBooking();
                    Toast.makeText(getApplicationContext(),"Booked",Toast.LENGTH_LONG).show();
                }


            }
        });


        Toolbar myChildToolbar = (Toolbar) findViewById(R.id.roomBookingToolbar);
        setSupportActionBar(myChildToolbar);
        ActionBar ab = getSupportActionBar();
        ab.setDisplayHomeAsUpEnabled(true);

    }

    private void insertInBooking() {
        myDataBase = Room.databaseBuilder(RoomBooking.this, MyDataBase.class,"ghaurihotelDB").allowMainThreadQueries().build();
        List<RoomType> data = myDataBase.dao().RommTypeDao(selectedRoomType);
        for(int i=0;i<data.size();i++) {
            try {
                int roomTypeID = data.get(i).getRoomTypeID();
                Log.d("DATA", String.valueOf("room type id "+roomTypeID));
                List<RoomDetail> data1 = myDataBase.dao().RommDetailDao(1,roomTypeID);
                for(int j=0;j<data1.size();j++) {
                    try {
                        roomdetailID = data1.get(j).getRoomID();
                    }
                    catch (Exception e){
                        Log.d("ex",""+e);
                    }
                }
            }
            catch (Exception e){
                Log.d("ex",""+e);
            }
        }

        BookingDate checkINDate1 = new BookingDate(checkInDay,checkInMonth,checkInDYear);
        myDataBase = Room.databaseBuilder(RoomBooking.this, MyDataBase.class,"ghaurihotelDB").allowMainThreadQueries().build();
        int checkIN = (int) myDataBase.dao().bookingDateDao(checkINDate1);


        BookingDate checkOUTDate1 = new BookingDate(checkOutDay,checkOutMonth,checkOutYear);
        int checkOUT = (int) myDataBase.dao().bookingDateDao(checkOUTDate1);

        Address hotelAddress = new Address(countryCustomer.getSelectedItem().toString(),provinceCustomer.getSelectedItem().toString(),cityCustomer.getSelectedItem().toString(),townValueCustomer.getText().toString(),townValueCustomer.getText().toString());
        int address1 = (int) myDataBase.dao().addressDetails(hotelAddress);

        Customer customer = new Customer(nameCustomer.getText().toString(),emailCustomer.getText().toString(),cnicCustomer.getText().toString(),contactCustomer.getText().toString(),address1);
        int customerID = (int) myDataBase.dao().customerDao(customer);

        Booking booking1 = new Booking(roomdetailID,customerID,checkIN,checkOUT,true,numberOfRooms);
        myDataBase.dao().booking(booking1);

        nameCustomer.setText("");
        cnicCustomer.setText("");
        contactCustomer.setText("");
        addressValueCustomer.setText("");
        townValueCustomer.setText("");
        emailCustomer.setText("");


        Intent intent = new Intent(getApplicationContext(),HomePage.class);
        startActivity(intent);




    }

}
