package com.example.ghaurihotel;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.room.Room;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.example.ghaurihotel.DataBase.MyDataBase;
import com.example.ghaurihotel.DataBase.Tables.Booking;
import com.example.ghaurihotel.DataBase.Tables.BookingDate;
import com.example.ghaurihotel.DataBase.Tables.RoomDetail;
import com.example.ghaurihotel.DataBase.Tables.RoomType;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MyBooking extends AppCompatActivity {

    private MyDataBase myDataBase;
    public String typeName;
    public String checkInDate;
    public String checkOutDate;
    TextView myBookingDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_booking);

        myBookingDetails =(TextView) findViewById(R.id.myBookingDetails);
        bookingDisabled();

        Date date = new Date();
        Calendar c = Calendar.getInstance();
        Date currentDate = new Date();
        currentDate.setDate(c.get(Calendar.DAY_OF_MONTH));
        currentDate.setMonth(c.get(Calendar.MONTH)+1);
        currentDate.setYear( c.get(Calendar.YEAR));
     //   Log.d("DAT", String.valueOf("OK"+c.get(Calendar.DAY_OF_MONTH)+"/"+c.get(Calendar.MONTH)+"/"+c.get(Calendar.YEAR)));


        myDataBase = Room.databaseBuilder(MyBooking.this, MyDataBase.class,"ghaurihotelDB").allowMainThreadQueries().build();
        List<Booking> bookingObject = myDataBase.dao().myBooking();
        for(int k=0;k<bookingObject.size();k++) {
            try {
                if(bookingObject.get(k).isBooked()){
                    int temp = bookingObject.get(k).getRoomDetailID();
                    int checkIN = bookingObject.get(k).getCheckIn();
                    int checkOut = bookingObject.get(k).getCheckOut();


                    List<BookingDate> dateInOfMyBooking = myDataBase.dao().search(checkIN);
                    for(int l=0;l<dateInOfMyBooking.size();l++) {
                        try {
                            checkInDate = dateInOfMyBooking.get(l).getDay()+"/"+dateInOfMyBooking.get(l).getMonth()+"/"+dateInOfMyBooking.get(l).getYear();
                        }
                        catch (Exception e){
                            Log.d("ex",""+e);
                        }
                    }
                    List<BookingDate> dateOutOfMyBooking = myDataBase.dao().search(checkOut);
                    for(int l=0;l<dateOutOfMyBooking.size();l++) {
                        try {
                            checkOutDate = dateOutOfMyBooking.get(l).getDay()+"/"+dateOutOfMyBooking.get(l).getMonth()+"/"+dateOutOfMyBooking.get(l).getYear();
                        }
                        catch (Exception e){
                            Log.d("ex",""+e);
                        }
                    }

                    List<RoomDetail> roomDetailsObject = myDataBase.dao().myBookingRoomDetails(temp);
                    for(int j=0;j<roomDetailsObject.size();j++) {
                        try {
                            int temp1 = roomDetailsObject.get(j).getRoomTypeID();
                            List<RoomType> rommTypeObject = myDataBase.dao().RommTypeObject(temp1);
                            for(int l=0;l<rommTypeObject.size();l++) {
                                try {
                                    typeName = rommTypeObject.get(l).getRoomTypeName();
                                }
                                catch (Exception e){
                                    Log.d("ex",""+e);
                                }
                            }
                        }
                        catch (Exception e){
                            Log.d("ex",""+e);
                        }
                    }

                    Log.d("DATA", String.valueOf("OK1"+c.get(Calendar.DAY_OF_MONTH)+"/"+c.get(Calendar.MONTH)+"/"+c.get(Calendar.YEAR)));
                    String temp2 = "\n"+typeName+"\t"+bookingObject.get(k).getNumberOfRoom()+"\t"+checkInDate+"\t"+checkOutDate;
                            myBookingDetails.append(temp2);

                }


            }
            catch (Exception e){
                Log.d("ex",""+e);
            }


        }



        Toolbar myChildToolbar = (Toolbar) findViewById(R.id.roomBookingToolbar);
        setSupportActionBar(myChildToolbar);
        ActionBar ab = getSupportActionBar();
        ab.setDisplayHomeAsUpEnabled(true);
    }
    public void bookingDisabled() {

        Date date = new Date();
        Calendar c = Calendar.getInstance();
        Date currentDate = new Date();
        currentDate.setDate(c.get(Calendar.DAY_OF_MONTH));
        currentDate.setMonth(c.get(Calendar.MONTH)+1);
        currentDate.setYear( c.get(Calendar.YEAR));
        Log.d("DATA", String.valueOf("OK2"+c.get(Calendar.DAY_OF_MONTH)+"/"+(c.get(Calendar.MONTH)+1)+"/"+c.get(Calendar.YEAR)));


        myDataBase = Room.databaseBuilder(MyBooking.this, MyDataBase.class,"ghaurihotelDB").allowMainThreadQueries().build();
        List<Booking> bookingObject = myDataBase.dao().myBooking();
        for(int k=0;k<bookingObject.size();k++) {
            try {
                int checkIN = bookingObject.get(k).getCheckIn();


                List<BookingDate> dateInOfMyBooking = myDataBase.dao().search(checkIN);
                for(int l=0;l<dateInOfMyBooking.size();l++) {
                    try {
                        date.setDate(dateInOfMyBooking.get(l).getDay());
                        date.setMonth(dateInOfMyBooking.get(l).getMonth());
                        date.setYear(dateInOfMyBooking.get(l).getYear());


                        Log.d("DATA","OK"+dateInOfMyBooking.get(l).getDay()+"/"+dateInOfMyBooking.get(l).getMonth()+"/"+dateInOfMyBooking.get(l).getYear());




                    }
                    catch (Exception e){
                        Log.d("ex",""+e);
                    }
                    //  0 comes when two date are same,
                    //  1 comes when date1 is higher then date2
                    // -1 comes when date1 is lower then date2

                    if(date.compareTo(currentDate) < 0 ){
                        myDataBase.dao().update(false,bookingObject.get(k).getBookingID());
                    }
                }



            }
            catch (Exception e){
                Log.d("ex",""+e);
            }


        }

    }
}
